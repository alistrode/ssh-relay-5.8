#!/bin/sh
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd) || exit 1
exec "$ROOT/CLI.sh" start "$@"
