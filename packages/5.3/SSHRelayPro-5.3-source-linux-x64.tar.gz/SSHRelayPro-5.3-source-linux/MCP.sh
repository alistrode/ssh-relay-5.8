#!/bin/sh
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd) || exit 1
exec "$ROOT/runtime/node" "$ROOT/src/mcp.cjs" "$@"
