SSH Relay Pro 5.3 完整源码及 Linux x64 命令行运行包
解压后 ./Start.sh 启动近端，./CLI.sh --help 查看命令，./MCP.sh 启动 MCP。
内含原始源码、锁文件、生产依赖和 Node 运行时；无需 npm install。桌面界面需另用已有完整桌面包。
运行环境：Linux x64、glibc 2.28+、系统 OpenSSH 客户端。
未包含任何配对码、设备授权或私钥。设备状态默认保存于用户目录。
源码提交：78ca9abdbe95788a001bc9e25cabfb33a4b0ea04
第三方依赖来源、版本和许可证见 package-lock.json、node_modules 各包许可证。Node 来源 https://nodejs.org/，许可证见 runtime/NODE-LICENSE.txt。
