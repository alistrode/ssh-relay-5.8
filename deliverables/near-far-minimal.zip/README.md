# Minimal public near/far runtime

Requires existing Node.js 22+; no npm install needed. Windows: run START-REMOTE.cmd. Linux: run sh START-REMOTE.sh. Keep the window open. Give the complete PRIVATE connection block only to your trusted AI. Update BOTH near and far and verify relay_protocol=2. This archive contains generated runtime bundles, not original source.

AI near-end: use the bundled .agents/skills/connect-*/scripts/connect.py with --platform linux or win10 and --info-file /private/incoming.txt. Python 3.10+ and OpenSSH are required. The helper uses this archive's src/near.cjs; skip npm ci for this prebundled archive. Verify actual hostname/account and pinned SSH fingerprint. Do not upload data/, connection blocks, keys or logs.

MCP tools, profiles, prompts and full application source are in source.zip; unpack it and use npm ci --ignore-scripts, then follow docs/MCP-MANUAL.md. This minimal runtime supplies the current near/far connection only.

Private state is generated locally in data/ on first launch. Never copy old runtime data into a public location. Diagnostic metadata: data/far-events.jsonl and the private near state directory. Node.js itself is not bundled.
