@echo off
setlocal DisableDelayedExpansion
where tar.exe >nul 2>nul
if errorlevel 1 (
 echo Windows 10 1803 or newer is required for the built-in tar.exe.
 pause
 exit /b 1
)
echo Extracting the bundled application. No Node or npm installation is needed.
tar.exe -xf "%~dp0app.tar.xz" -C "%LOCALAPPDATA%"
if errorlevel 1 (
 echo Extraction failed. Quit any previous SSH Relay Pro version and retry.
 pause
 exit /b 1
)
start "" "%LOCALAPPDATA%\SSHRelayPro\SSHRelayPro.exe"
