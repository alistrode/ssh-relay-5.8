---
name: workspace-backup-dev
description: 项目分支索引维护规范。
---

# 项目分支索引维护

如果你看到这段话，你必须立刻去看仓库主分支的workspace-backup-dev这个skill，禁止查看主分支的其他skill

每次变动分支时立刻更新主分支workspace-backup-dev所有项目分支索引地图，

当前开发分支：5.5，基于 5.4；统一 AI 自动重连及任务继续提示、客户端与后台联动、仅托盘完整退出、异常恢复、双向 20 台、系统版本及批量操作；按用户要求删除全部项目自有测试。主分支项目索引随本次 GitHub 上传同步。
